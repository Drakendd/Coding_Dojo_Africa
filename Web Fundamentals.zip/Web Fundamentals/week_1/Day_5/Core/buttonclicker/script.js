

function hide(element){
    element.remove();
}
function change(element) {
    element.innerHTML ="logout";
}

